<?php
$mod_strings['LBL_SALESAGILITY_ADMIN'] = 'Advanced OpenAdmin';
$mod_strings['LBL_AOS_ADMIN_CONTRACT_SETTINGS'] = 'Contract Settings';
$mod_strings['LBL_AOS_ADMIN_CONTRACT_RENEWAL_REMINDER'] = 'Renewal Reminder period';
$mod_strings['LBL_AOS_ADMIN_MANAGE_AOS'] = 'Advanced OpenSales Settings';
$mod_strings['LBL_AOS_ADMIN_INVOICE_SETTINGS'] = 'Invoice Settings';
$mod_strings['LBL_AOS_ADMIN_INITIAL_INVOICE_NUMBER'] = 'Initial Invoice Number';
$mod_strings['LBL_AOS_ADMIN_QUOTE_SETTINGS'] = 'Quote Settings';
$mod_strings['LBL_AOS_ADMIN_INITIAL_QUOTE_NUMBER'] = 'Initial Quote Number';
$mod_strings['LBL_AOS_ADMIN_LINE_ITEM_SETTINGS'] = 'Line Item Settings';
$mod_strings['LBL_AOS_ADMIN_ENABLE_LINE_ITEM_GROUPS'] = 'Enable Line Items Groups';
$mod_strings['LBL_AOS_ADMIN_ENABLE_LINE_ITEM_TOTAL_TAX'] = 'Add TAX To Line Total';
$mod_strings['LBL_AOS_SETTINGS'] = 'AOS Settings';
$mod_strings['LBL_AOS_PRODUCTS'] = 'AOS Products';
$mod_strings['LBL_AOS_EDIT'] = 'edit';
$mod_strings['LBL_AOS_DAYS'] = 'days';
$mod_strings['LBL_CHANGE_SETTINGS'] = 'Change settings for Advanced OpenSales';
